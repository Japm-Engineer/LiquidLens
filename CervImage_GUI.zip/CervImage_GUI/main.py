from gui_app.startup_window import StartupWindow
from PyQt5.QtWidgets import QApplication

if __name__ == "__main__":
    app = QApplication([])
    startup = StartupWindow()
    startup.show()
    app.exec_()