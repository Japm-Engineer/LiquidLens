# -*- coding: utf-8 -*-
"""
Created on Mon Oct 11 13:12:42 2021

@author: Stanley
"""

# importing the module
import pickle
import os

def read_config_file(configFilepath):
    with open(configFilepath, 'rb') as handle:
    	data = handle.read()

    # reconstructing the data as dictionary
    return( pickle.loads(data) )

class ConfigFileCreator:

    def write_CervImageConfiguration(self):
        numPics = 36 # number of pictures in set
        delay = 0.05 # seconds
        highRes = False # high resolution mode
        initialV = 24. # volts
        finalV = 60. # volts
        restV = initialV #(finalV - initialV) / 2. # volts
        exposure = 60000# ms
        whiteBalance = ((429./256.), (427./256.)) # off
        brightnessScale = 31./10. # scaling for LEDs
        
        analogGain = 2.0
        digitalGain = 1.0
        highResExposure = 50000
        lowResExposure = 20000
        highResFramerate = 20
        lowResFramerate = 50
        
        
        initialBrightness = 2 # initial LED brightness
        
        imageCodec = "MJPG" # intrinsic image codec
        imageBackend = "CAP_DSHOW" # cv2 backend
        
        ##### DICTIONARY OF CONFIG PROPERTIES #####
        configDictionary = {'num_pics': numPics,
            'cam_delay_sec': delay,
            'high_res_mode': highRes,
            'initial_voltage': initialV,
            'final_voltage': finalV,
            'rest_voltage': restV,
            'exposure_ms': exposure,
            'auto_whitebalance': whiteBalance,
            'bright_scale': brightnessScale,
            'bright_initial': initialBrightness,
            'image_codec_fourcc': imageCodec,
            'image_backend': imageBackend,
            'analog_gain': analogGain,
            'digital_gain': digitalGain,
            'high_res_exposure': highResExposure,
            'low_res_exposure': lowResExposure,
            'high_res_framerate': highResFramerate,
            'low_res_framerate': lowResFramerate}

        cervimage_config_name = "cervimage_config.txt"

        self.cervimage_config_path = self.write_config(cervimage_config_name, configDictionary)
        
    def write_AmazonConfiguration(self):
        masterBucket = "cervimagedev1"
        queueBucket = masterBucket + "queue"
        
        bucketDictionary = {"bucket": masterBucket, 
                            "queuebucket": queueBucket}
        
        amazon_config_name = 'amazon_config.txt'
        
        self.amazon_config_path = self.write_config(amazon_config_name, bucketDictionary)
    
    def __init__(self): 
        self.outdir = os.getcwd() + "//"
        self.outdir = self.outdir.replace("\\","//").replace("//","/")
        
    def write_config(self, confname, confdict):
        
        #confname = "amazon_config.txt"
        
        config_path = self.outdir+confname
        # opening file in write mode (binary)
        file = open(config_path, "wb")



        # serializing dictionary
        pickle.dump(confdict, file)

        # closing the file
        file.close()
        
        return config_path

if __name__ == "__main__":
    cf = ConfigFileCreator()
    
    cf.write_AmazonConfiguration()
    cf.write_CervImageConfiguration()

    # reading the data from the file
    for fullpath in [cf.amazon_config_path, cf.cervimage_config_path]:
        print(read_config_file(fullpath))
        """
        with open(fullpath, 'rb') as handle:
        	data = handle.read()
        
        print("Data type before reconstruction : ", type(data))
        
        # reconstructing the data as dictionary
        d = pickle.loads(data)
        
        print("Data type after reconstruction : ", type(d))
        print(d)
        """