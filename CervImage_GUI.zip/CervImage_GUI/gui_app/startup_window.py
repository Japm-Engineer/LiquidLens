import subprocess
from PyQt5.QtWidgets import QMainWindow, QLabel, QPushButton, QVBoxLayout, QWidget
from PyQt5.QtCore import QCoreApplication, Qt
from PyQt5.QtGui import QFont, QColor
import shutil
import platform
from gui_app.main_menu import MainMenu
from gui_app.network_check_window import NetworksWindow


# Battery Level
def get_battery_level():
    try:
        if platform.system() == "Linux":
            result = subprocess.check_output(["upower", "-i", "/org/freedesktop/UPower/devices/battery_BAT0"])
            result = result.decode("utf-8")
            for line in result.splitlines():
                if "percentage" in line:
                    return int(line.strip().split()[1].strip("%"))
    except Exception as e:
        print("Error getting battery level:", e)
    return "N/A"


# Available Storage
def get_available_storage():
    try:
        total, used, free = shutil.disk_usage("/")
        return free / (2**30)  # Convert bytes to GB
    except Exception as e:
        print("Error getting available storage:", e)
    return "N/A"


# Internet Connection
def is_internet_connected():
    try:
        subprocess.check_call(["ping", "-c", "1", "google.com"])

        #subprocess.check_call(["runas", "ping", "-c", "1", "google.com"]) # windows
        return True
    except subprocess.CalledProcessError:
        return False


class StartupWindow(QMainWindow):
    def __init__(self):
        super(StartupWindow, self).__init__()
        self.setWindowTitle("Startup Window")
        self.setGeometry(100, 100, 800, 480)  # Set window size here

        self.init_ui()

    def init_ui(self):
        main_widget = QWidget(self)
        main_layout = QVBoxLayout(main_widget)
        btm_layout = QVBoxLayout(main_widget)
        self.setCentralWidget(main_widget)
        
        # Set text colors and fonts
        indicator_font = QFont("Arial", 14, QFont.Bold)
        
       # battery_label = QLabel(f"Battery Level: {get_battery_level()}%", self)
       # battery_label.setFont(indicator_font)
        storage_label = QLabel("Available Storage: {:.2} GB".format(get_available_storage()), self)
        storage_label.setFont(indicator_font)
        internet_label = QLabel("Internet: Connected" if is_internet_connected() else "Internet: Disconnected", self)
        internet_label.setFont(indicator_font)
        
        
        self.btn_check_networks = QPushButton(self)
        self.btn_check_networks.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/networks_button.png)")
        self.btn_check_networks.setFixedSize(140, 50)
        self.btn_check_networks.clicked.connect(self.open_networks_window)
        
        self.btn_check_networks.setEnabled(False)
        self.btn_check_networks.hide()
        
        self.btn_continue = QPushButton(self)
        self.btn_continue.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/continue_button.png)")
        self.btn_continue.setFixedSize(140, 50)
        self.btn_continue.clicked.connect(self.open_main_menu)
        
        
       # main_layout.addWidget(battery_label)
        main_layout.addWidget(storage_label)
        main_layout.addWidget(internet_label)
        
        btm_layout.addWidget(self.btn_check_networks)
        btm_layout.addWidget(self.btn_continue)
        btm_layout.setAlignment(Qt.AlignCenter)
        
        main_layout.addLayout(btm_layout)

    def open_networks_window(self):
        self.btn_check_networks.setEnabled(False)
        self.btn_continue.setEnabled(False)
        QCoreApplication.processEvents()
        
        self.networks_window = NetworksWindow()
        self.networks_window.show()
        
        self.btn_check_networks.setEnabled(True)
        self.btn_continue.setEnabled(True)
        QCoreApplication.processEvents()
    
    def open_main_menu(self):
        self.main_menu = MainMenu()
        self.main_menu.show()
        self.close()