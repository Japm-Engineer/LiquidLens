import serial
import codecs
global colorList
from gui_app.apa102_modified import APA102
import RPi.GPIO as GPIO


colorList = ("white", "red", "green", "blue")

class LightDriver:

  def loadLED(self, initial):
      leds = APA102(num_led=4)

      # Setting initial brightness
      for i in range(4):
          leds.set_pixel_rgb(i, 0xFFFFFF, initial)  # self.brightnessInitial)
      leds.show()

      return leds

  def __init__(self, initialBrightness=0):  # b_scale = 31./10., b_init = 0.):
      self.leds = self.loadLED(initialBrightness)
      print("Initialized LEDs inside LightDriver")
      # self.brightnessInitial = (31./10.) * self.brightnessInitial

  def _setPixelBrightness(self, brightness, colorcode):
      for i in range(4):
          self.leds.set_pixel_rgb(i, colorcode, int(brightness))
      self.leds.show()

  def setBrightness(self, brightness, colorsetting=0):

      hexcodes = (0xFFFFFF, 0xFF0000, 0x00FF00, 0x0000FF)
      # if colorsetting:
      # colorsetting = colorsetting# + 1
      colorcode = hexcodes[colorsetting]
      # else:
      # 33      colorcode = hexcodes[0]
      # colorsetting = col+1
      # print(int(brightness))
      self._setPixelBrightness(brightness, colorcode)
      # for i in range(4):
      #    self.leds.set_pixel_rgb(i, colorcode, int(brightness))

      # print("\n")

  # print("Color is: ",colorList[colorsetting])
  # print("Brightness is: ", str(int(brightness)))

  def lightsOff(self):
      self.setBrightness(0)  # , 0xFFFFFF)
      # for i in range(4):
  #     self.leds.set_pixel_rgb(i, 0xFFFFFF, 0) # setting leds to off
  # self.leds.show()