import pickle

from pathlib import Path


import time
import threading
from threading import Thread
from queue import LifoQueue
from gui_app.amazon_s3_functions import AmazonS3Server
#import logging
import sys
import numpy as np
import queue

import os
#import trace
from PIL import Image, ImageTk
import cv2


class DataUpload:
        
    def uploadFunction(self):#queue, serverObject, alldirs):
        #queue, serverObject, alldirs = self.queue, self.amazon, self.alldirs#args[0], args[1], args[2]
        self.amazon = AmazonS3Server()#self.mainpath)
        print("Thread 1 running")
        self.threadrunning = True
     #   mpath = "C:/Users/Stanley/Desktop/Image_Library/"
        if self.manualupload:
            
            if type(self.alldirs) == list:
                self.datasetsRemaining = len(self.alldirs)
            
                for director in self.alldirs:
                    self.datasetsRemaining -= 1
                    print("director is ", director)
                    #fpath = mpath+director+"/"
                    #fpath = fpath.replace("\\","/").replace("//","/")
                    self.currentUpload = director.replace("\\","/").replace("//","/")
                    
                    #try:
                    #    if self.lesiononly:
                    #        self.amazon.uploadLesion(self.currentUpload)
                    #except:
                    
                    self.amazon.uploadDataset(self.currentUpload)#"))#self.mainpath+director)
                self.datasetsRemaining = False
            else:
                print("Manual directory: ",self.alldirs)
                self.datasetsRemaining = 0
                #self.alldirs = self.alldirs[0]
                self.currentUpload = self.alldirs.replace("\\","/").replace("//","/")
                print(self.currentUpload)
                if self.lesiononly:
                    self.amazon.uploadLesion(self.currentUpload)
                else:
                    self.amazon.uploadDataset(self.currentUpload)#"))#self.mainpath+director)
        else:
            
            self.datasetsRemaining = len(self.alldirs)
            
            for director in self.alldirs:
                self.datasetsRemaining -= 1
                print("director is ", director)
                #fpath = mpath+director+"/"
                #fpath = fpath.replace("\\","/").replace("//","/")
                self.currentUpload = director.replace("\\","/").replace("//","/")
                
                #try:
                #    if self.lesiononly:
                #        self.amazon.uploadLesion(self.currentUpload)
                #except:
                
                self.amazon.uploadDataset(self.currentUpload)#"))#self.mainpath+director)
            self.datasetsRemaining = False
                
        print("Thread 1 ending")
        self.threadrunning = None
        self.queue.put("Upload\ncomplete!")
       # self.alldirs = None
        if not self.manualupload:
            self.cerv.CervImageClass.uploadfiles = False
            self.alldirs = False
            del self.cerv.CervImageClass.uploadfiles
            del self.alldirs
        self.manualupload = False       


    def cancel_upload(self):
        #global stop_threads
       # stop_threads = True
       
        self.threadrunning = None
        print("Cancelled upload")
        self.uploadthread.kill()
        print("Killed thread")
        self.uploadthread.join()
        print("Joined thread")
        self.queue.put("Upload\ncancelled!")
        
        ### WRITING TO UPLOAD.TXT TO INDICATE FAILURE
       # print(self.mainpath+self.currentUpload)
        f = open(self.currentUpload+'/upload.txt','w')#opening a txt file to write info to
        TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
        f.write("Files uploaded on\n")
        f.write("Date = " + TIME + ' \n')
        #f.close() #must also close the file
        f.write("FAILED")
       # f.write("Date = " + TIME + ' \n')
        f.close() #must also close the file
        
        if os.path.exists(self.currentUpload+"/lesionupload.txt"):
           f = open(self.currentUpload+"/lesionupload.txt","w")
           TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
           f.write("Lesion files uploaded on\n")
           f.write("Date = " + TIME + ' \n')
           f.write("FAILED")
           f.close()
        #############################################
        if not self.manualupload:
            self.cerv.CervImageClass.uploadfiles = False
            del self.cerv.CervImageClass.uploadfiles
            self.alldirs = False
            del self.alldirs
        self.manualupload = False
        
    def begin_uploading(self, *args):
        #self.mainpath = "/home/pi/Desktop/Image_Library/"
        self.mainpath = Path(self.programPath)#"/here/your/path/file.txt")
        self.mainpath = self.mainpath.parent.absolute()
        self.mainpath = os.path.dirname(self.mainpath) + "/"
        self.mainpath = self.mainpath.replace("\\","/").replace("//","/")
        self.mainpath = self.mainpath + "Image_Library/"
        print("Mainpath to upload: ",self.mainpath)
        #self.mainpath + "Image_Library/"
        #print(path.parent.absolute())

        
       # print(args[0])
        self.manualupload = False
        try:
            arguments = args[0]
            self.alldirs = arguments[0]
            self.lesiononly = arguments[1]
            print("Passed manual dataset upload")
            print("Directories: ",self.alldirs)
            print("Directory type: ",type(self.alldirs))
            self.manualupload = True
        except:
            pass
       # print(self.cerv.CervImageClass.uploadfiles)
        #global stop_threads
        #stop_threads = False
        try:
            if self.cerv.CervImageClass.uploadfiles:
                self.alldirs = self.cerv.CervImageClass.uploadfiles
                #self.cerv.up
                print("Passed CervImage dataset upload")
        except:
            pass
        
        print("Tried to upload")
        try:
            if self.alldirs:
                baddata = False
                if self.manualupload == False:
                    for dat in self.alldirs:
                        print("Datasets to upload: ",dat)
                        if "dataset_" not in dat:
                            baddata = True
                            break #self.alldirs:
                if baddata:
                    print("Something went wrong")
                    print("Alldirs: ",self.alldirs)
                    self.cerv.CervImageClass.uploadfiles = False
                    del self.cerv.CervImageClass.uploadfiles
                    self.alldirs = False
                    del self.alldirs
                else:    
                    print("There is a file")
                   # uploaddirs = self.cerv.CervImageClass.uploadfiles#[]
                    
                    #if self.amazon.success:
                    print("Threaded upload in progress")
                    self.uploadbutton.configure(text="Uploading files\nPress to cancel")
                    self.uploadbutton['state'] = 'normal'
                    self.root.update_idletasks()
                     
                    #self.alldirs = uploaddirs
                    self.queue = queue.Queue()
                    self.uploadthread = thread_with_trace(target = self.uploadFunction)#, args=(self,))#, args=[(self.queue, self.amazon, self.alldirs)])#ThreadedTask(self.queue, self.amazon, self.alldirs).start()
                    print("Init thread")
                    self.uploadthread.daemon = True
                    self.uploadthread.start()
                    print("Started thread")
                    #self.root.after(1000, self.process_queue)
                    self.process_queue()
                    #elf.root.after(500, self.process_queue)
        except:
            print("Didn't upload anything")
            pass
     #   else:
        #print("Not connected to Amazon S3!")
      #  self.queue = queue.Queue()
       # self.queue.put("Not connected\nto upload server!")
       # self.root.after(1000, self.process_queue)
        # except:
      #      pass
                
    def process_queue(self):
        try:
            msg = self.queue.get(0)
            #print("Tried for message")
            
            try:
           # if not self.manualupload:
                self.cerv.CervImageClass.uploadfiles = False
                del self.cerv.CervImageClass.uploadfiles
                print("Deleted cerv.uploadfiles")
            except:
                pass
            
            try:
                self.alldirs = False
                del self.alldirs
                print("Deleted alldirs")
            except:
                pass
            
            #self.alldirs = None
            # Show result of the task if needed
            self.uploadbutton.configure(text=msg)
            self.uploadbutton['state'] = 'disabled'
            self.root.update_idletasks()
            time.sleep(1)
            self.uploadbutton.configure(text="No upload\nin progress")
            self.root.update_idletasks()
            self.manualupload = False
            
        except queue.Empty:
            global processJob
            processJob = self.root.after(100, self.process_queue)
            #print("Empty queue")
            #print(self.amazon.count)
            
            try:
                theCount = self.amazon.count 
            except:
                theCount = 33
            ### DEBUGGING
            DEBUG_PROCESS = False
            if DEBUG_PROCESS:
                print("Got initial count: ", theCount)
                print("Datasets remaining: ", self.datasetsRemaining)
                countmsg = False
                
                print("Manual upload: ", self.manualupload)
                
                if not self.manualupload:
                    print("Condition 1: ", True)
                
                if self.manualupload:
                    print("Manual upload: ", self.manualupload)
                    if self.datasetsRemaining:
                        print("Condition 2: ", True)
            ###
            
            if (not self.manualupload) or (self.manualupload and self.datasetsRemaining):
                #print("Updated theCount")
                theCount = theCount + 33*self.datasetsRemaining
                
            countmsg = str(theCount)+" images\nleft to upload\nPress to cancel"
            self.uploadbutton.configure(text=countmsg)
            self.root.update_idletasks()
            #except AttributeError:
            #    print("No count yet, tryin again")
