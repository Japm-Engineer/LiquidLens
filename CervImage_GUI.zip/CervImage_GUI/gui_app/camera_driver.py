import picamerax
import picamera
import picamera.array
from time import sleep
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QImage, QPixmap
import os

# Need liquid lens control since capture_continuous must be defined inside camera driver
from gui_app.liquid_lens_driver import LiquidLensDriver

class CameraDriver:
  
  def setExposure(self):
      # self.cam.iso = 500
      
      sleep(2) # Let automatic gain control settle
      
      
      #self.cam.shutter_speed = self.exposure
      self.cam.exposure_mode = 'off'
      
      self.cam.analog_gain = self.analogGain
      self.cam.digital_gain = self.digitalGain
      
      g = self.cam.awb_gains # Gets the AWB gains before turning AWB off
      self.cam.awb_mode = 'off' # Turns off AWB
      self.cam.awb_gains = self.whitebalance # Sets the AWB gains to the saved values
      
      print('Exposure: ' + str(self.cam.shutter_speed))
      print('White Balance: ' + str(self.cam.awb_gains))
      print('Analog Gain: ' + str(self.cam.analog_gain))
      print('Digital Gain: ' + str(self.cam.digital_gain))
      
      #self.cam.awb_gains = self.whitebalance

  def loadCamera(self, dev=-1):
      # self.canChangeSettings = True

      # dev = -1
      #camera = picamera.PiCamera()
      # camera.sensor_mode=7
      # camera.resolution=(640, 480)
      # camera.framerate = 80
      print('loaded camera')
      
      # self.rawCapture = np.empty((480,640,3), dtype=np.uint8)#picamera.array.PiRGBArray(camera, size=(640,480))
      return picamerax.PiCamera()  # self.cv2.VideoCapture(dev, cv2.CAP_V4L)

  def closeCamera(self):
      self.cam.close()


  def _setLowRes(self):
      # self.LIVE_CAMERA = False
      sleep(0.1)

      self.cam.sensor_mode = 7
      self.cam.resolution = (640, 480)
      self.cam.framerate = self.lowResFramerate
      self.cam.shutter_speed = self.lowResExposure
      # self.rawCapture = np.empty((480,640,3), dtype=np.uint8)
      self.rawCapture = picamera.array.PiRGBArray(self.cam, size=(640, 480))
      # self.LIVE_CAMERA = True
      
      print(' Low Res Exposure: ' + str(self.cam.shutter_speed))
      print('Analog Gain: ' + str(self.cam.analog_gain))
      print('Digital Gain: ' + str(self.cam.digital_gain))
      print("Set low res mode")
      

  def lowResMode(self):  # , camObj):
      self.LIVE_CAMERA = False
      self._setLowRes()
      self.LIVE_CAMERA = True

  def _setHighRes(self):

      # self.LIVE_CAMERA = False
      sleep(0.1)
      self.cam.sensor_mode =  1
      self.cam.resolution = (1920, 1088) # (1280,720)
      self.cam.framerate = self.highResFramerate  # 40
      self.cam.shutter_speed = self.highResExposure
      # self.rawCapture = np.empty((720,1280,3), dtype=np.uint8)
      self.rawCapture = picamera.array.PiRGBArray(self.cam, size=(1920, 1088))  # (,720))
      # self.LIVE_CAMERA = True
      '''
      print('High Res Exposure: ' + str(self.cam.shutter_speed))
      print('Analog Gain: ' + str(self.cam.analog_gain))
      print('Digital Gain: ' + str(self.cam.digital_gain))
      '''
      print("Set high res mode")

  def highResMode(self):  # , camObj):
      self.LIVE_CAMERA = False
      self._setHighRes()
      self.LIVE_CAMERA = True
      
      
  def capture_temporary(self, stream):
      
      self.cam.capture(stream, format='jpeg', use_video_port=True)#, splitter_port=0) 

  def _reader(self):

      while not self.STOP_READING:
          if self.LIVE_CAMERA:
              liveimage = self._takeImg(video_port=False)
              while not imageQ.empty():
                  try:
                      self.imageQ.get(timeout=0.05)
                  except Empty:
                      pass
              self.imageQ.put(liveimage)
            

  def _takeImg(self, videoPort=False):
      
      self.cam.capture(self.rawCapture, format='bgr', use_video_port=False)
      image = self.rawCapture.array
      self.rawCapture.truncate(0)
      # r, img = self.cam.read()
      
      return image  # self.rawCapture
    
  def _changeVoltage(self, voltage):
      self.lens.set_voltage(voltage)
     # print('set voltage to: ' + str(voltage))
      sleep(self.lens_delay)
      return

#   def takeImgContinuous(self, dataset_name=False):#, dataset_num=0, trial_num=0):
#       self._changeVoltage(self.initial_voltage)
#       path = '/home/pi/Desktop/Image_Library/' + str(dataset_name) + '/'
#       os.makedirs(path, exist_ok=True)
#       pictures = []
#       try:
#           output = picamera.array.PiRGBArray(self.cam)
#           i = 0
#           for foo in self.cam.capture_continuous(output, format = 'rgb', use_video_port=True):
#               pictures.append(output.array)
#               output.truncate(0)
#               self._changeVoltage(self.voltages[i])
#               i += 1
#               if i == 30:
#                   break
#       finally:
#           pass
#         
#       return pictures
#    
  def takeImgContinuous(self, videoPort=False, dataset_name=False,
                        dataset_notes=False, config=False):
      self._changeVoltage(self.initial_voltage)
      
      if dataset_name[0] == " ":
          dataset_name = dataset_name[1::] # removes leading whitespace
      
      path = '/home/pi/Desktop/Image_Library/' + str(dataset_name)
#       os.makedirs(path, exist_ok=True)
      if os.path.isdir(path):  # self.imagedir+dirname):#maindir+"\\"+dirname):
          print("Existing direct found")
          # os.chdir(self.imagedir+dirname)#maindir+'\\'+dirname)
      else:
          print("New direct", path, "created")
          os.makedirs(path)
          
      for i in range(1, 100):
          current_path = path + "/dataset_" + str(i)
          if os.path.exists(current_path):
              current_last = path + "/dataset_" + str(i)
              continue
          else:
              print("New dataset", current_path, " created")
              current_last = path  + "/dataset_" + str(i)
              os.mkdir(current_path)
              break
            
      filenames = []
      try:
          for i, filename in enumerate(
              self.cam.capture_continuous(current_path + '/Image{counter:02d}.jpg', use_video_port=False)):
             #added splitter port=1, did not help issue (TEST)
              filename = filename.split('/')[-1]
              filenames.append(filename)
              self._changeVoltage(self.voltages[i])
              if i == 31:
                  break
      finally:
          pass
        
      
      #self.TIME = time.strftime("%d-%b-%Y_%H%M_%S", time.localtime())
      f = open(current_path + '/data.txt', 'w')  # opening a txt file to write info to
     # Writing to the file
      f.write(dataset_name + '\n')
      f.write("FILES = " + str(filenames) + ' \n')
     # f.write("Date = " + self.TIME + ' \n')
      # f.write("TIMES = " + str(imageSet.getTimes()) +' \n')
      f.write("VOLTAGES = " + str(self.voltages) + " \n")
      # f.write(InfoChecks()+' \n')
      f.write("note = " + str(dataset_notes) + " \n")  # imageList.getNote()+ ' \n')
      f.write('Device Settings: ' + str(config) + "\n")
      # f.write(note + ' \n')

      f.close()  # must also close the file
    

  def getImg(self, datasetImage=False):
      return self._takeImg(videoPort=datasetImage)

  def __init__(self, settingsList=False, imageQ=False):  # , imageQ, controlQ):

      
      self.exposure =  settingsList['exposure']
      self.whitebalance = settingsList['whitebalance']
      self.voltages = settingsList['voltages']
      self.initial_voltage = settingsList['initial_voltage']
      self.lens_delay = settingsList['lens_delay']
      
      self.analogGain = settingsList['analog_gain']
      self.digitalGain = settingsList['digital_gain']
      self.highResExposure = settingsList['high_res_exposure']
      self.lowResExposure = settingsList['low_res_exposure']
      self.highResFramerate = settingsList['high_res_framerate']
      self.lowResFramerate = settingsList['low_res_framerate']
      
      # creating an instance of voltageDriver within the camera class so that it can be
      # accessed by the capture_continuous loop
      print("trying to load voltage driver inside CameraDriver")
      self.lens = LiquidLensDriver(initial=self.initial_voltage)
      self.lens.set_voltage() # INITIAL MIDDLE VOLTAGE
      print('loaded voltage driver for capture_continuous')


      # print("Initial low res mode")
      self.cam = self.loadCamera()  # cv2.VideoCapture(dev)
      print('initializing camera')
      self.cam.rotation = 180
      self.setExposure()
      self.lowResMode()  # self.cam)
      
      

      #self.imageQ = False
      if imageQ:
          print("Starting camera threading")
          self.STOP_READING = False
          self.LIVE_CAMERA = True
          self.imageQ = imageQ
          self.t = threading.Thread(target=self._reader)
          self.t.daemon = True
          self.t.start()
          