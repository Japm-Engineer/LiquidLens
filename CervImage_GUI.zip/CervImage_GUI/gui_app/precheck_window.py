import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QGridLayout, QVBoxLayout, QWidget, QPushButton
from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal, QCoreApplication
import socket
from PyQt5.QtGui import QPixmap, QFont, QColor
import time
from time import sleep

import picamerax
import picamera
import picamera.array

from gui_app.camera_viewer import CameraViewerWindow
from gui_app.liquid_lens_driver import LiquidLensDriver
from gui_app.light_driver import LightDriver

class ErrorCheckThread(QThread):
    
    cam_status = pyqtSignal(bool)
    internet_status = pyqtSignal(bool)
    lens_status = pyqtSignal(bool)
    LED_status = pyqtSignal(bool)
    check_complete = pyqtSignal(bool)
    
    def __init__(self):
        super(ErrorCheckThread, self).__init__()

    def run(self):
        camera_working = self.check_camera()
        self.cam_status.emit(camera_working)
        
        lens_working = self.check_liquid_lens()
        self.lens_status.emit(lens_working)
        
        LED_working = self.check_LED()
        self.LED_status.emit(LED_working)
        
        internet_working = self.check_internet()
        self.internet_status.emit(internet_working)
        
        complete = True
        self.check_complete.emit(complete)

    def check_camera(self):
        print("Beginning camera test...")
        # Setting up camera up front to avoid re-initializing it
        try:
            camera = picamerax.PiCamera()
            camera.resolution = (640,480)
            camera.framerate = 24
            print("Initialized camera")
            success=True
        except:
            success=False # Camera failed to initialize, auto-fail
        
        try:
            camera.close()
            sleep(1)
            print("Closed camera in error window")
        except:
            print("Failed to close camera, auto-fail")
            success=False
        
        if success:
            return True
        else:
            return False

    def check_liquid_lens(self):
        print("Beginning liquid lens test...")
        try:
            liquid = LiquidLensDriver()
            liquid.set_voltage(shutdown=True)
            return True
        except:
            return False
    
    def check_LED(self):
        print("Beginning light ring test...")
        try:
            leds = LightDriver()
            leds.setBrightness(10, 2)
            leds.lightsOff()
            return True
        except:
            return False
    
    def check_internet(self):
        print("Beginning Internet test...")
        try:
            # Attempt to connect to a known external server
            socket.create_connection(("www.google.com", 80))
            return True
        except OSError:
            return False

class ErrorCheckWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Error Checking Window")
        self.setGeometry(100, 100, 800, 480)

        # Establish grid layout for GUI widgets        
        grid_layout = QGridLayout()
        
        btm_layout = QVBoxLayout()
        
        main_layout = QVBoxLayout()
        # Success/Failure messages for each component
        lightSuccessMessage = "LED light ring is functioning!"
        lightFailureMessage = "LED light ring is not functioning!\
                    \n(1) Make sure that CervImage is powered on and displaying a green light on the handle.\
                    \n(2) Check if USB-C cable is plugged in!\
                    \n(3) If light ring still fails while USB-C is plugged in, flip the USB-C and plug back in."

        liquidSuccessMessage = "Liquid lens is functioning!"
        liquidFailureMessage = "Liquid lens is not functioning!\
                    \n(1) Make sure that CervImage is powered on and displaying a green light on the handle.\
                    \n(2) Check if USB-C cable is plugged in!\
                    \n(3) If liquid lens still fails while USB-C is plugged in, flip the USB-C and plug back in."

        cameraSuccessMessage = "Camera is functioning!"
        cameraFailureMessage = "Camera is not functioning!\nMake sure that camera cable from the CervImage handle\n is plugged into a square USB port."

        internetSuccessMessage = "Internet is connected!"
        internetFailureMessage = "Internet is not connected!\nMake sure that the Raspberry Pi is connected\n to WiFi or with an Ethernet cable.\nProgram will still proceed without Internet."
        
        # Set text colors and fonts
        indicator_font = QFont("Arial", 12, QFont.Bold)
        small_font = QFont("Arial", 10)
        success_color = QColor(0, 128, 0)  # Green
        failure_color = QColor(255, 0, 0)  # Red
        
        # Attach success/failure messages to Qt objects
        self.camera_success = QLabel(cameraSuccessMessage, self)
        self.camera_success.setFont(indicator_font)
        self.camera_success.setMaximumWidth(500)
        self.camera_success.setStyleSheet(f"color: {success_color.name()}")
        self.camera_success.hide()
        
        self.internet_success = QLabel(internetSuccessMessage, self)
        self.internet_success.setFont(indicator_font)
        self.internet_success.setMaximumWidth(500)
        self.internet_success.setStyleSheet(f"color: {success_color.name()}")
        self.internet_success.hide()
        
        self.lens_success = QLabel(liquidSuccessMessage, self)
        self.lens_success.setFont(indicator_font)
        self.lens_success.setMaximumWidth(500)
        self.lens_success.setStyleSheet(f"color: {success_color.name()}")
        self.lens_success.hide()
        
        self.LED_success = QLabel(lightSuccessMessage, self)
        self.LED_success.setFont(indicator_font)
        self.LED_success.setMaximumWidth(500)
        self.LED_success.setStyleSheet(f"color: {success_color.name()}")
        self.LED_success.hide()
        
        self.camera_failure = QLabel(cameraFailureMessage, self)
        self.camera_failure.setFont(small_font)
        self.camera_failure.setMaximumWidth(500)
        self.camera_failure.setStyleSheet(f"color: {failure_color.name()}")
        self.camera_failure.hide()
        
        self.internet_failure = QLabel(internetFailureMessage, self)
        self.internet_failure.setFont(small_font)
        self.internet_failure.setMaximumWidth(500)
        self.internet_failure.setStyleSheet(f"color: {failure_color.name()}")
        self.internet_failure.hide()
        
        self.lens_failure = QLabel(liquidFailureMessage, self)
        self.lens_failure.setFont(small_font)
        self.lens_failure.setMaximumWidth(500)
        self.lens_failure.setStyleSheet(f"color: {failure_color.name()}")
        self.lens_failure.hide()
        
        self.LED_failure = QLabel(lightFailureMessage, self)
        self.LED_failure.setFont(small_font)
        self.LED_failure.setMaximumWidth(500)
        self.LED_failure.setStyleSheet(f"color: {failure_color.name()}")
        self.LED_failure.hide()
        
        # GUI elements for component status indicators
        self.camera_text = QLabel("Camera Status:", self)
        self.camera_text.setFont(indicator_font)
        self.camera_text.show()
        
        self.camera_indicator = QLabel("", self)
        self.camera_indicator.show()
        
        self.internet_text = QLabel("Internet Status:", self)
        self.internet_text.setFont(indicator_font)
        self.internet_text.show()
        
        self.internet_indicator = QLabel("", self)
        self.internet_indicator.show()
        
        self.lens_text = QLabel("Liquid Lens Status:", self)
        self.lens_text.setFont(indicator_font)
        self.lens_text.show()
        
        self.lens_indicator = QLabel("Liquid Lens", self)
        self.lens_indicator.show()
        
        self.LED_text = QLabel("LED Status:", self)
        self.LED_text.setFont(indicator_font)
        self.LED_text.show()
        
        self.LED_indicator = QLabel("LEDs", self)
        self.LED_indicator.show()
        
        self.check_button = QPushButton("Check Components", self)
        self.check_button.clicked.connect(self.start_check_thread)
        self.check_button.setMaximumWidth(500)
        self.check_button.setEnabled(False)
        self.check_button.hide()
        
        self.begin_label = QLabel("Beginning CervImage Component Checks...", self)
        self.begin_label.setMaximumWidth(600)
        self.begin_label.setFont(indicator_font)
        self.begin_label.setAlignment(Qt.AlignCenter)

        self.loading_label = QLabel("Checking Components...", self)  # Use a label for animation
        self.loading_label.setAlignment(Qt.AlignCenter)
        self.loading_label.setFont(indicator_font)
        self.loading_label.setMaximumWidth(600)
        self.loading_label.hide()
        
        self.continue_label = QLabel("Opening Camera Viewer, please wait...")
        self.continue_label.setAlignment(Qt.AlignCenter)
        self.continue_label.setFont(indicator_font)
        self.continue_label.setMaximumWidth(600)
        self.continue_label.setStyleSheet(f"color: {success_color.name()}")
        self.continue_label.hide()
        
        
        self.btn_close = QPushButton(self)
        self.btn_close.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/menu_button.png)")
        self.btn_close.setFixedSize(100, 70)
        self.btn_close.clicked.connect(self.close)
        
        # Add all text and indicator elements to grid layout
        
        grid_layout.addWidget(self.btn_close, 1, 4)
        grid_layout.addWidget(self.camera_text, 0, 0)
        grid_layout.addWidget(self.camera_indicator, 1, 0)
        
        grid_layout.addWidget(self.camera_success, 1, 2)
        grid_layout.addWidget(self.camera_failure, 1, 2)
        
        grid_layout.addWidget(self.internet_text, 2, 0)
        grid_layout.addWidget(self.internet_indicator, 3, 0)
        
        grid_layout.addWidget(self.internet_success, 3, 2)
        grid_layout.addWidget(self.internet_failure, 3, 2)
        
        grid_layout.addWidget(self.lens_text, 4, 0)
        grid_layout.addWidget(self.lens_indicator, 5, 0)
        
        grid_layout.addWidget(self.lens_success, 5, 2)
        grid_layout.addWidget(self.lens_failure, 5, 2)
        
        grid_layout.addWidget(self.LED_text, 6, 0)
        grid_layout.addWidget(self.LED_indicator, 7, 0)
        
        grid_layout.addWidget(self.LED_success, 7, 2)
        grid_layout.addWidget(self.LED_failure, 7, 2)
        

        btm_layout.addWidget(self.loading_label)
        btm_layout.addWidget(self.check_button)
        btm_layout.addWidget(self.continue_label)
        btm_layout.addWidget(self.begin_label)
        btm_layout.setAlignment(Qt.AlignCenter)
        btm_layout.setSpacing(0)
        
        
        main_layout.addLayout(grid_layout)
        main_layout.addLayout(btm_layout)
        main_layout.setSpacing(0)
        
        # Set color images for the QLabel indicators
        self.gray_button = QPixmap("/home/pi/Desktop/CervImage_GUI/gui_app/icons/gray_button.png")
        self.red_button = QPixmap("/home/pi/Desktop/CervImage_GUI/gui_app/icons/red_button.png")
        self.orange_button = QPixmap("/home/pi/Desktop/CervImage_GUI/gui_app/icons/orange_button.png")
        self.green_button = QPixmap("/home/pi/Desktop/CervImage_GUI/gui_app/icons/green_button.png")
        
        # Set all indicators to gray
        self.camera_indicator.setPixmap(self.gray_button)
        self.internet_indicator.setPixmap(self.gray_button)
        self.lens_indicator.setPixmap(self.gray_button)
        self.LED_indicator.setPixmap(self.gray_button)
        
        
        central_widget = QWidget(self)
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)
        
 
        self.start_check_thread()
        
        
    def reset_messages(self):
        self.begin_label.hide()
        self.camera_success.hide()
        self.camera_failure.hide()
        self.internet_success.hide()
        self.internet_failure.hide()
        self.lens_success.hide()
        self.lens_failure.hide()
        self.LED_success.hide()
        self.LED_failure.hide()
        
    def reset_indicators(self):
        self.camera_indicator.setPixmap(self.gray_button)
        self.internet_indicator.setPixmap(self.gray_button)
        self.lens_indicator.setPixmap(self.gray_button)
        self.LED_indicator.setPixmap(self.gray_button)
        
    def start_check_thread(self):

        
        # Reset indicator colors
        self.reset_indicators()
        
        # Hide success/failure messages
        self.reset_messages()
        
        # Show "Checking components..." loading message
        self.loading_label.show()
        self.loading_label.setText("Checking Components...")  # Reset the loading label
        self.check_button.setEnabled(False)  # Disable the button during checks
        self.check_button.hide()
        self.btn_close.setEnabled(False)
        # Start error checking thread
        self.error_check_thread = ErrorCheckThread()
        self.error_check_thread.cam_status.connect(self.update_cam_status)
        self.error_check_thread.internet_status.connect(self.update_internet_status)
        self.error_check_thread.lens_status.connect(self.update_lens_status)
        self.error_check_thread.LED_status.connect(self.update_LED_status)
        self.error_check_thread.check_complete.connect(self.finish_checks)
        self.error_check_thread.start()

        # Start a timer to simulate the loading animation
        self.loading_timer = QTimer(self)
        self.loading_timer.timeout.connect(self.update_loading_label)
        self.loading_timer.start(300)  # Update every 500 ms

    def update_loading_label(self):
        current_text = self.loading_label.text()
        if current_text.endswith("..."):
            current_text = "Checking Components"
        else:
            current_text += "."
        self.loading_label.setText(current_text)

    def update_cam_status(self, camera_working):
        self.camera_working = camera_working
        if camera_working:
            self.camera_indicator.setPixmap(self.green_button)
            self.camera_success.show()
            sleep(.25)
        else:
            sleep(.25)
            self.camera_success.hide()
            self.camera_failure.show()
            self.camera_indicator.setPixmap(self.red_button)
        QCoreApplication.processEvents()
    
    def update_internet_status(self, internet_working):
        self.internet_working = internet_working
        if internet_working:
            self.internet_indicator.setPixmap(self.green_button)
            self.internet_success.show()
            sleep(.25)
        else:
            sleep(.25)
            self.internet_success.hide()
            self.internet_indicator.setPixmap(self.orange_button)
            self.internet_failure.show()
        QCoreApplication.processEvents()
        
    def update_lens_status(self, lens_working):
        self.lens_working = lens_working
        if lens_working:
            self.lens_indicator.setPixmap(self.green_button)
            self.lens_success.show()
            sleep(.25)
        else:
            sleep(.25)
            self.lens_success.hide()
            self.lens_indicator.setPixmap(self.red_button)
            self.lens_failure.show()
        QCoreApplication.processEvents()
        
    def update_LED_status(self, LED_working):
        self.LED_working = LED_working
        if LED_working:
            self.LED_indicator.setPixmap(self.green_button)
            self.LED_success.show()
            sleep(.25)
        else:
            sleep(.25)
            self.LED_success.hide()
            self.LED_indicator.setPixmap(self.red_button)
            self.LED_failure.show()
        QCoreApplication.processEvents()
        
    def finish_checks(self, finished):
        
        if finished:
            self.loading_timer.stop()  # Stop the loading animation timer
            self.loading_label.hide()

            self.btn_close.setEnabled(True)
            if self.camera_working and self.lens_working and self.LED_working:
                self.check_button.hide()
                QCoreApplication.processEvents()
                self.continue_label.show()
                QCoreApplication.processEvents()
                sleep(2)
                QCoreApplication.processEvents()
                sleep(.5)
                self.open_cam_viewer()
                self.close()
            else:
                self.check_button.setEnabled(True)  # Enable check components button
                self.check_button.show()

    def open_cam_viewer(self):
        self.camera_viewer_window = CameraViewerWindow()
        self.camera_viewer_window.show()
        
        
# if __name__ == "__main__":
#     app = QApplication(sys.argv)
#     error_check_window = ErrorCheckWindow()
#     error_check_window.show()
#     sys.exit(app.exec_())
