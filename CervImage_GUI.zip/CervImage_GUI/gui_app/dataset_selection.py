import os
from PyQt5.QtWidgets import QMainWindow, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QWidget, QComboBox
from PyQt5.QtGui import QPixmap, QFont, QColor
from PyQt5.QtCore import Qt, QCoreApplication, QObject, QThread, pyqtSignal
from gui_app.amazon_s3_functions import UploadThread, UploadPatientThread, UploadAllThread
import time
import threading
import cv2


# Dataset viewer class
class CaptureViewerWindow(QMainWindow):
    def __init__(self):
        super(CaptureViewerWindow, self).__init__()
        self.setWindowTitle("Captured Datasets")
        self.setGeometry(100, 100, 800, 480)  # Set window size
        self.init_ui()

    def init_ui(self):
        main_widget = QWidget(self)
        main_layout = QVBoxLayout(main_widget)
        self.setCentralWidget(main_widget)

        # Create a top layout for buttons
        top_layout = QHBoxLayout()
        self.btn_close = QPushButton("Main Menu", self)
        self.btn_close.clicked.connect(self.close_window)
        self.btn_close.setMaximumWidth(200)
        self.btn_close.setStyleSheet("background-color: white; color: red;")
        top_layout.addStretch(1)  # Push the button to the right
        top_layout.addWidget(self.btn_close)
        main_layout.addLayout(top_layout)

        self.upload_patient_btn = QPushButton("Upload Patient", self)
        self.upload_patient_btn.clicked.connect(self.upload_all_for_patient)
        self.upload_patient_btn.setMaximumWidth(800)
        self.upload_patient_btn.setStyleSheet("background-color: white; color: red;")
        top_layout.addStretch(1)  # Push the button to the right
        top_layout.addWidget(self.upload_patient_btn)
        
        self.upload_btn = QPushButton("Upload Dataset", self)
        self.upload_btn.clicked.connect(self.upload_dataset)
        self.upload_btn.setMaximumWidth(300)
        self.upload_btn.setStyleSheet("background-color: white; color: red;")
        top_layout.addStretch(1)  # Push the button to the right
        top_layout.addWidget(self.upload_btn)

        self.upload_all_btn = QPushButton("Upload All Patient Data", self)
        self.upload_all_btn.clicked.connect(self.upload_all_data)
        self.upload_all_btn.setMaximumWidth(300)
        self.upload_all_btn.setStyleSheet("background-color: white; color: red;")
        top_layout.addStretch(1)  # Push the button to the right
        top_layout.addWidget(self.upload_all_btn)
        
        self.dataset_selector = QComboBox(self)
        self.dataset_selector.currentIndexChanged.connect(self.load_selected_dataset)
        main_layout.addWidget(self.dataset_selector)

        self.sub_dataset_selector = QComboBox(self)
        self.sub_dataset_selector.currentIndexChanged.connect(self.load_selected_sub_dataset)
        main_layout.addWidget(self.sub_dataset_selector)

        self.image_label = QLabel(self)
        main_layout.addWidget(self.image_label)

        self.btn_previous = QPushButton("Previous", self)
        self.btn_previous.clicked.connect(self.show_previous_image)
        self.btn_next = QPushButton("Next", self)
        self.btn_next.clicked.connect(self.show_next_image)
        
        # Set text colors and fonts
        indicator_font = QFont("Arial", 12, QFont.Bold)
        success_color = QColor(0, 128, 0)  # Green
        failure_color = QColor(255, 0, 0)  # Red
        
        self.image_name = QLabel("Current Image", self)
        self.image_name.setAlignment(Qt.AlignCenter)
        self.image_name.setFont(indicator_font)
        
        
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.btn_previous)
        button_layout.addWidget(self.image_name)
        button_layout.addWidget(self.btn_next)
        main_layout.addLayout(button_layout)
        
        self.image_library_path = "/home/pi/Desktop/Image_Library/"
       # self.image_library_path = os.path.join(os.path.expanduser("~"), "Desktop", "Image_Library")
        self.current_dataset = None
        self.current_sub_dataset = None
        self.current_images = []
        self.current_image_index = 0

        self.load_datasets()

    def close_window(self):
        self.close()

    def load_datasets(self):
        self.datasets = [folder for folder in os.listdir(self.image_library_path) if
                    os.path.isdir(os.path.join(self.image_library_path, folder))]
        # List datasets in chronological order
        self.datasets.sort()
        self.dataset_selector.addItems(self.datasets)

    def load_selected_dataset(self):
        self.current_dataset = self.dataset_selector.currentText()
        print(self.current_dataset)
        self.load_sub_datasets()
        self.load_images()
        self.upload_patient_btn.setText('Upload All Datasets For ' + str(self.current_dataset))
        QCoreApplication.processEvents()
    
    
    def disable_upload_btns(self):
        self.upload_btn.setEnabled(False)
        self.upload_patient_btn.setEnabled(False)
        self.upload_all_btn.setEnabled(False)
    
    def enable_upload_btns(self):
        self.upload_btn.setEnabled(True)
        self.upload_patient_btn.setEnabled(True)
        self.upload_all_btn.setEnabled(True)
    
    def upload_dataset(self):
        self.disable_upload_btns()
        self.mode = 'upload dataset'
        self.thread = QThread()
        # Step 3: Create a worker object
        self.worker = UploadThread(self.current_sub_dataset, self.current_dataset)
        # Step 4: Move worker to the thread
        self.worker.moveToThread(self.thread)
        # Step 5: Connect signals and slots
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()
        
        # Final resets
       # self.upload_btn.setEnabled(False)
        self.thread.finished.connect(
            lambda: self.enable_upload_btns()
        )
        QCoreApplication.processEvents()
        
        
    def upload_all_for_patient(self):
        self.disable_upload_btns()
        self.mode = 'upload patient'
        # Step 2: Create a QThread object
        self.thread = QThread()
        # Step 3: Create a worker object
        self.worker = UploadPatientThread(self.sub_datasets, self.current_dataset)
        # Step 4: Move worker to the thread
        self.worker.moveToThread(self.thread)
        # Step 5: Connect signals and slots
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        # Step 6: Start the thread
        self.thread.start()
        
        # Final GUI element resets
      #  self.upload_patient_btn.setEnabled(False)
        self.thread.finished.connect(
            lambda: self.enable_upload_btns()
        )
    
    def upload_all_data(self):
        self.disable_upload_btns()
        self.mode = 'upload all'
        # Step 2: Create a QThread object
        self.thread = QThread()
        # Step 3: Create a worker object
        self.worker = UploadAllThread(self.datasets, self.image_library_path)
        # Step 4: Move worker to the thread
        self.worker.moveToThread(self.thread)
        # Step 5: Connect signals and slots
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        # Step 6: Start the thread
        self.thread.start()
        
        # Final GUI element resets
      #  self.upload_all_btn.setEnabled(False)
        self.thread.finished.connect(
            lambda: self.enable_upload_btns()
        )
        
        
    def update_progress(self, remaining_files):
 
        if self.mode == 'upload dataset':
            if remaining_files > 0:
                self.upload_btn.setText(f"Files Remaining: {remaining_files}")
                QCoreApplication.processEvents()
            else:
                self.upload_btn.setText('Upload Complete')
                QCoreApplication.processEvents()
        
        if self.mode == 'upload patient':
            if remaining_files > 0:
                self.upload_patient_btn.setText(f"Files Remaining: {remaining_files}")
                QCoreApplication.processEvents()
            else:
                self.upload_patient_btn.setText('Patient Upload Complete')
                QCoreApplication.processEvents()
        
        if self.mode == 'upload all':
            if remaining_files > 0:
                self.upload_all_btn.setText(f"Files Remaining: {remaining_files}")
                QCoreApplication.processEvents()
            else:
                self.upload_all_btn.setText('Uploaded All Patient Data')
                QCoreApplication.processEvents()
            
    def load_sub_datasets(self):
        if self.current_dataset:
            self.sub_datasets = [folder for folder in os.listdir(os.path.join(self.image_library_path, self.current_dataset))
                            if os.path.isdir(os.path.join(self.image_library_path, self.current_dataset, folder))]
            # List sub datasets in chronological order
            self.sub_datasets.sort()
            self.sub_dataset_selector.clear()
            self.sub_dataset_selector.addItems(self.sub_datasets)
            print(self.current_dataset)
            print(self.sub_datasets)

    def load_selected_sub_dataset(self):
        self.current_sub_dataset = self.sub_dataset_selector.currentText()
        self.load_images()
        self.upload_btn.setText('Upload ' + str(self.current_sub_dataset))
        QCoreApplication.processEvents()

    def load_images(self):
        if self.current_sub_dataset:
            dataset_path = os.path.join(self.image_library_path, self.current_dataset, self.current_sub_dataset)
            self.current_images = [file for file in os.listdir(dataset_path) if
                                   file.lower().endswith(('.jpg', '.png', '.jpeg', '.tiff'))]
            self.current_image_index = 0
            # Sort images in chronological order
            self.current_images.sort()
            self.load_image()

    def load_image(self):
        if self.current_images:
            image_path = os.path.join(self.image_library_path, self.current_dataset, self.current_sub_dataset,
                                      self.current_images[self.current_image_index])
            
            pixmap = QPixmap(image_path).scaled(640, 480)
            self.image_name.setText("Image " + str(image_path[-6:-4]))
            self.image_label.setPixmap(pixmap)
            self.image_label.setAlignment(Qt.AlignCenter)

    def show_previous_image(self):
        if self.current_images:
            self.current_image_index = (self.current_image_index - 1) % len(self.current_images)
            self.load_image()

    def show_next_image(self):
        if self.current_images:
            self.current_image_index = (self.current_image_index + 1) % len(self.current_images)
            self.load_image()
