from PyQt5.QtWidgets import QMainWindow, QMessageBox, QLabel, QPushButton, QListWidget, QVBoxLayout, QHBoxLayout, QWidget, QLineEdit, QComboBox
from PyQt5.QtCore import Qt
from wifi import Cell, Scheme
import subprocess

class NetworksWindow(QMainWindow):
    def __init__(self):
        super(NetworksWindow, self).__init__()
        self.setWindowTitle("Available Networks")
        self.setGeometry(100, 100, 800, 480)  # Set window size here

        self.init_ui()

    def init_ui(self):
        main_widget = QWidget(self)
        main_layout = QVBoxLayout(main_widget)
        
        mid_layout = QHBoxLayout()
        
        
        self.setCentralWidget(main_widget)

        self.networks_combo = QListWidget(self)

        
        password_label = QLabel("Password:", self)
        password_label.setAlignment(Qt.AlignCenter)
        password_input = QLineEdit(self)
        password_input.setMaximumWidth(150)
        btn_close = QPushButton("Quit", self)
        btn_close.clicked.connect(self.return_to_startup)
        btn_close.setMaximumWidth(100)
        
        btn_connect = QPushButton("Connect", self)
        btn_connect.clicked.connect(lambda: self.connect_to_selected_network(self.networks_combo.currentItem(), password_input.text()))
        
        
        mid_layout.addWidget(password_label)
        mid_layout.addWidget(password_input)
        mid_layout.addStretch(5)
        main_layout.addWidget(btn_close)
        main_layout.addWidget(self.networks_combo)
#         main_layout.addWidget(password_label)
#         main_layout.addWidget(password_input)
        main_layout.addLayout(mid_layout)
        main_layout.addWidget(btn_connect)
 
        self.update_network_list()
        

    def update_network_list(self):
        
        # Populate the networks_combo with available networks
        self.networks = Cell.all('wlan0')
        self.network_list = list(Cell.all('wlan0'))
        for network in self.network_list:
            name = network.ssid
            print(name)
            self.networks_combo.addItem(name)
    
 
        
    
    def return_to_startup(self):
        self.close()
        
    def connect_to_selected_network(self, network, password):
        
        if network:
            network_name = network
            if password:
                try:
                    # Generate a configuration entry and add it to the wpa_supplicant configuration file
                    config_entry = f'network={{\n  ssid="{network_name}"\n  psk="{password}"\n}}\n'
                    with open("/etc/wpa_supplicant/wpa_supplicant.conf", "a") as config_file:
                        config_file.write(config_entry)

                    # Restart the WiFi interface to apply the new configuration
                    subprocess.run(["sudo", "ifdown", "wlan0"])
                    subprocess.run(["sudo", "ifup", "wlan0"])

                except Exception as e:
                    print('Connection Error')
                    pass
