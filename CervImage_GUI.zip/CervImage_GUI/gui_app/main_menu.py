import sys
import os
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QIcon, QFont
from PyQt5.QtCore import Qt, QTimer, QObject, QCoreApplication, QSize
from PyQt5.QtWidgets import QMainWindow, QPushButton, QHBoxLayout, QVBoxLayout, QGridLayout, QWidget
from gui_app.dataset_selection import CaptureViewerWindow
from gui_app.camera_viewer import CameraViewerWindow
from gui_app.precheck_window import ErrorCheckWindow


class MainMenu(QMainWindow):
    def __init__(self):
        super(MainMenu, self).__init__()
        self.setWindowTitle("Pensieviewer Main Menu")
        self.setGeometry(100, 100, 800, 480)  # Set window size here

        self.init_ui()

    def init_ui(self):
        main_widget = QWidget(self)
        self.setCentralWidget(main_widget)
        grid_layout = QGridLayout(main_widget)
        
        
        btn_restart = QPushButton( self)
        btn_restart.clicked.connect(self.restart_application)
        btn_restart.setFixedSize(100, 70)
        btn_restart.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/restart_button_draft4.png)")

        btn_quit = QPushButton(self)
        btn_quit.clicked.connect(self.quit_application)
        btn_quit.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/small_quit_button.png)")
        btn_quit.setFixedSize(70, 70)
        
        
        
#         top_layout = QHBoxLayout()
#         top_layout.addWidget(btn_restart)
#         top_layout.addWidget(btn_quit)
#         top_layout.addStretch(1)  # Push buttons to the right
#         top_layout.setAlignment(Qt.AlignCenter)
#         main_layout.addLayout(top_layout)

        btn_camera_viewer = QPushButton(self)
        btn_camera_viewer.setMaximumWidth(150)
        btn_camera_viewer.setFixedSize(250, 125)
        btn_camera_viewer.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/camera_viewer_button.png)")
       
        btn_capture_viewer = QPushButton(self)
        btn_capture_viewer.setMaximumWidth(150)
        btn_capture_viewer.setFixedSize(250, 125)
        btn_capture_viewer.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/dataset_viewer_button.png)")
        
        btn_camera_viewer.clicked.connect(self.open_camera_viewer_window)
        btn_capture_viewer.clicked.connect(self.open_capture_viewer_window)


        
        grid_layout.addWidget(btn_restart, 0, 0)
        grid_layout.addWidget(btn_quit, 0, 3)
        
        grid_layout.addWidget(btn_camera_viewer, 1, 1)
        grid_layout.addWidget(btn_capture_viewer, 2, 1)
    # Update GUI software (IN PROGRESS)
    def update_application(self):
        pass

    def quit_application(self):
        self.close()

    def restart_application(self):
        self.close()
        python = sys.executable
        os.execl(python, python, *sys.argv)

    def open_camera_viewer_window(self):
        self.error_checking = ErrorCheckWindow()
        self.error_checking.show()

    def open_capture_viewer_window(self):
        self.capture_viewer_window = CaptureViewerWindow()
        self.capture_viewer_window.show()