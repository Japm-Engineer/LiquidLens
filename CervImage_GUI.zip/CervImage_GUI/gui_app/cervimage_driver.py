from gui_app.camera_driver import CameraDriver
from gui_app.liquid_lens_driver import LiquidLensDriver
from gui_app.light_driver import LightDriver
import pickle
import os
from PyQt5.QtCore import Qt


### CERVIMAGE CLASS ###

class CervImageDevice:
  def loadConfiguration(self):
      configDir = os.path.dirname(os.path.abspath(__file__))

      configName = configDir + "/cervimage_config.txt"

      with open(configName, 'rb') as handle:
          config = handle.read()

      # print("Data type before reconstruction : ", type(config)
      # reconstructing the data as dictionary
      d = pickle.loads(config)
      
      
      self.numPics = d['num_pics']
      self.lensDelay = d['cam_delay_sec']
      self.highresDataset = d['high_res_mode']
      self.voltageStart = d['initial_voltage']
      self.voltageEnd = d['final_voltage']
      self.voltStep = (self.voltageEnd - self.voltageStart) / self.numPics
      self.voltages = [self.voltageStart + voltIndex * self.voltStep for voltIndex in range(self.numPics + 1)]
      self.restVoltage = d['rest_voltage']
      self.brightScale = d['bright_scale']
      self.brightInitial = d['bright_initial']
      
      self.analogGain = d['analog_gain']
      self.digitalGain = d['digital_gain']
      self.highResExposure = d['high_res_exposure']
      self.lowResExposure = d['low_res_exposure']
      self.highResFramerate = d['high_res_framerate']
      self.lowResFramerate = d['low_res_framerate']

      # Raspberry Pi specific
      self.exposure = d['exposure_ms']
      self.whiteBalance = d['auto_whitebalance']
      self.videoCodec = d['image_codec_fourcc']
      # self.videoCodec = [self.videoCodecRaw[0], self.videoCodecRaw[1], self.videoCodecRaw[2], self.videoCodecRaw[3]]
      # self.
          # self.MULTIPROCESS_CAMERA = True
      print('Loaded configuration file')

  """
  def applyConfiguration(self, cameraController):
      if cameraController.systemType == 'rpi':
          command = "v4l2-ctl -d /dev/video0 -c exposure_auto=1 -c exposure_absolute=" + self.exposure#str(512)#156)
          output = subprocess.call(command, shell=True)
          command = "v4l2-ctl -d /dev/video0 -c white_balance_temperature_auto="+ self.whiteBalance#"0"
          output = subprocess.call(command, shell=True)
          cameraController.cam.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(self.videoCodec[0], self.videoCodec[1], self.videoCodec[2], self.videoCodec[3]))#'Y', 'U', 'Y', 'V'))
  """

  def __init__(self, imageQ=False, controlQ=False, inputQ=False):
      print("Initializing CervImageDevice class")
#       global RASPBERRY_FLAG
#       self.IsRaspberryPi = RASPBERRY_FLAG  # For external checking

      print("Starting to load queues...")
      self.imageQ = imageQ
      self.controlQ = False#controlQ
      self.inputQ = False#inputQ
      print('Loaded queues')
      self.loadConfiguration()
      
      # restVoltage = self.voltageEnd - self.voltageStart
      self.lens = LiquidLensDriver(self.restVoltage)
      print('Voltage driver is now responsibility of camera')
      #CameraDriver will now handle voltage change
      camSettings = {"exposure": self.exposure,
                     "whitebalance": self.whiteBalance,
                     "voltages": self.voltages,
                     "initial_voltage": self.voltageStart,
                     "lens_delay": self.lensDelay,
                     "analog_gain": self.analogGain,
                     "digital_gain": self.digitalGain,
                     "high_res_exposure": self.highResExposure,
                     "low_res_exposure": self.lowResExposure,
                     "high_res_framerate": self.highResFramerate,
                     "low_res_framerate": self.lowResFramerate}


      print("CODEC IS: ", self.videoCodec[0], ",", self.videoCodec[1], ",", self.videoCodec[2], ",",
            self.videoCodec[3])
      self.cam = CameraDriver(imageQ=self.imageQ, settingsList=camSettings)
      self.cam.lowResMode()
      print("Loaded camera from CervImage Device class")

      self.lights = LightDriver(initialBrightness=self.brightScale * self.brightInitial)  # bright_scale = self.brightScale, bright_init= self.brightInitial)
      print("Loaded LightDriver")
      self.currentBright = self.brightInitial
      print("Set initial brightness")

  
  def resetVoltage(self):
      self.cam._changeVoltage(self.restVoltage)
  
  def captureTemp(self, stream):
      
      self.cam.capture_temporary(stream)
      

  def captureSingle(self, voltage=False, highres=False, dataset=False):
      # Voltage setting
      if voltage:
          print("captureSingle not setting voltage anymore")
          #self.lens.set_voltage(volt=voltage)
          #sleep(self.lensDelay)

      # Capture settings
      if highres:
          print("High res single capture")
          self.cam.highResMode()
          capture = self.cam.getImg(datasetImage=dataset)
          self.cam.lowResMode()
      else:
          capture = self.cam.getImg(datasetImage=dataset)
          #datasetImage=dataset represents the state of the video port (true/false)
          """
          if dataset:
              capture = self.cam._takeImg()
          else:
              capture = self.cam.getImg()
         # print(capture.shape)
          """

      return capture

  # Faster method of capturing a SFF data
  def captureCont(self, highresol=False,
                  dataset_name=False,dataset_notes=False,
                  config=False):#, dataset_num=0, trial_num=0):
      if highresol:   
          self.cam.highResMode()
      filename = dataset_name
      self.cam.takeImgContinuous(dataset_name=filename,
                                            dataset_notes=dataset_notes,
                                            config=config)
      
      self.cam.lowResMode()
          
#           
#       if RASPBERRY_FLAG:  # and self.GPIO_FLAG:
#           GPIO.output(5, False)  # Turns off yellow status indicator LED
#           self.GPIO_FLAG = False
          
        
        
  def captureDataset(self, highresol=False):
      # highresol = True#self.highresDataset

      global RASPBERRY_FLAG
      if RASPBERRY_FLAG:  # and self.GPIO_FLAG:
          GPIO.output(5, True)  # Turns on yellow status indicator LED

      self.lens.set_voltage(volt=self.voltageStart)

      if highresol:  # Turns on high-res mode
          self.cam.highResMode()
          self.LIVE_PREVIEW = False

      dataset = [self.captureSingle(voltage=volt, dataset=True) for volt in self.voltages]

      """
      for voltIndex in range(self.numPics + 1):
          currentVoltage = self.voltageStart + voltIndex*self.voltStep
          dataset.append(self.captureSingle(voltage=currentVoltage))
      """
      if highresol:  # Turns off high-res mode
          self.cam.lowResMode()
          # self.controlQ.put("2")
          # sleep(0.25)
          # self.cam.lowResMode()
          # trash = self.cam.getImg()
      # else:
      #    self.cam.highResMode()

      self.lens.set_voltage()  # Returning to middle voltage

      if RASPBERRY_FLAG:  # and self.GPIO_FLAG:
          GPIO.output(5, False)  # Turns off yellow status indicator LED
          self.GPIO_FLAG = False

      return dataset

  def setBrightness(self, bright, color=False):
      pass
      scaledBright = self.brightScale * bright
      self.lights.setBrightness(scaledBright, colorsetting=color)
      self.currentBright = bright
      
      
  def reloadCamera(self):
      self.cam.loadCamera()
      self.cam.lowResMode()
      
      
  def shutdownDevice(self):
      self.cam.lens.set_voltage(shutdown=True)
      self.lights.lightsOff()
      print("Closing camera...")
      self.cam.closeCamera()
      

  def GPIO_Setup(self):
      pass
      ### Making LEDs work
#       GPIO.setwarnings(False)
#       GPIO.setmode(GPIO.BCM)
#       GPIO.setup(4, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)  # Detect button press
#       GPIO.setup(5, GPIO.OUT)  # Yellow LED
#       GPIO.output(5, False)  # Yellow off

      # self.GPIO_FLAG = False # If True, should take a dataset

  def GPIO_Listen(self):
      pass
#       global RASPBERRY_FLAG
# 
#       if RASPBERRY_FLAG and GPIO.input(4) == True:  # Detect button press and take pictures
#           self.GPIO_FLAG = True
#       else:
#           self.GPIO_FLAG = False
