import os
import sys
import threading
import time
from PyQt5.QtCore import Qt, QTimer, QObject, QCoreApplication, QSize
from PyQt5.QtGui import QImage, QPixmap, QPainter, QColor, QIcon, QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QGridLayout, QPushButton, QLabel, QHBoxLayout, QVBoxLayout
from gui_app.cervimage_driver import CervImageDevice
from io import BytesIO   


class CameraViewerWindow(QMainWindow):
    def __init__(self):
        super(CameraViewerWindow, self).__init__()
        self.setWindowTitle("Camera Viewer")
        self.setGeometry(100, 100, 800, 480)  # Set window size
        
        # CervImage device driver
        self.cerv = CervImageDevice()
        self.current_brightness = self.cerv.brightInitial
        
        self.init_ui()
        
        # Thread for handling camera stream
        self.running = True
        self.camera_thread = threading.Thread(target=self.update_camera_viewer)
        self.camera_thread.daemon = True
        self.camera_thread.start()
        
    def init_ui(self):
        main_widget = QWidget(self)
        self.setCentralWidget(main_widget)

        # Set text colors and fonts
        indicator_font = QFont("Arial", 12, QFont.Bold)
        success_color = QColor(0, 128, 0)  # Green
        failure_color = QColor(255, 0, 0)  # Red
        
        
        layout_all = QHBoxLayout(main_widget)
        layout_left = QVBoxLayout()
        layout_right = QVBoxLayout()
        layout_btm_right = QVBoxLayout()
        
        
        # Q Object for containing camera stream
        self.label_stream = QLabel(self)
        
        # Resolution for camera streaming
        self.label_stream.setFixedSize(640, 480)
        
        layout_left.addWidget(self.label_stream)
        
        self.capturing_overlay = QWidget(self)
        self.capturing_overlay.setFixedSize(640, 480)
        self.capturing_overlay.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/progress1.png)")
        self.capturing_overlay.hide()
        layout_left.addWidget(self.capturing_overlay)
        
        # Text for patient 
        self.patient = "Patient 1"
        self.patient_label = QLabel(self.patient, self)
        self.patient_label.setAlignment(Qt.AlignCenter)
        self.patient_label.setFont(indicator_font)
        self.patient_label.setText("Viewing " + str(self.patient))
        layout_left.addWidget(self.patient_label) 
        
        # Close window button
        self.btn_close = QPushButton(self)
        self.btn_close.clicked.connect(self.close_window)
        self.btn_close.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/menu_button.png)")
        self.btn_close.setFixedSize(100, 70)
        layout_right.addWidget(self.btn_close)
        
        # Capture dataset button
        self.btn_capture_dataset = QPushButton(self)
        self.btn_capture_dataset.clicked.connect(self.capture_dataset)
        self.btn_capture_dataset.setFixedSize(145, 225)
        self.btn_capture_dataset.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/big_camera_icon.png)")
        layout_right.addWidget(self.btn_capture_dataset)
        
        self.brightness_label = QLabel("Brightness: " + str(self.current_brightness), self)
        self.brightness_label.setAlignment(Qt.AlignCenter)
        self.brightness_label.setMaximumWidth(150)
        self.brightness_label.setFont(indicator_font)
        layout_btm_right.addWidget(self.brightness_label)
        
        
        self.bright_up = QPushButton(self)
        self.bright_up.clicked.connect(self.increase_brightness)
        self.bright_up.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/new_up_arrow.png)")
        self.bright_up.setFixedSize(100, 50)
        layout_btm_right.addWidget(self.bright_up)
        
        self.bright_down = QPushButton(self)
        self.bright_down.clicked.connect(self.decrease_brightness)
        self.bright_down.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/new_down_arrow.png)")
        self.bright_down.setFixedSize(100, 50)
        layout_btm_right.addWidget(self.bright_down)
        
        layout_btm_right.setSpacing(10)
        layout_right.addLayout(layout_btm_right)
        layout_right.setSpacing(10)
        layout_all.addLayout(layout_left)
        layout_all.addLayout(layout_right)

        
    def increase_brightness(self):
        self.current_brightness += 1
        self.cerv.setBrightness(self.current_brightness)
        self.brightness_label.setText("Brightness: " + str(self.current_brightness))
        QCoreApplication.processEvents()
    
    def decrease_brightness(self):
        self.current_brightness -= 1
        self.cerv.setBrightness(self.current_brightness)
        self.brightness_label.setText("Brightness: " + str(self.current_brightness))
        QCoreApplication.processEvents()
        
        
    def update_camera_viewer(self):
        self.cerv.resetVoltage()
        while self.running:
            stream = BytesIO()  # Create a stream to capture the image
            self.cerv.captureTemp(stream)
            stream.seek(0)  # Move the stream cursor to the beginning
            pixmap = QPixmap()
            pixmap.loadFromData(stream.read())  # Load the image data into the pixmap
            self.label_stream.setPixmap(pixmap)
            time.sleep(0.01)
        else:
            print('Camera stream ended...')
            pass

    # Capture a shape-from-focus dataset
    
    # Need to add error handling for image capture, and add the error overlay
    def capture_dataset(self):
        print("Pausing camera stream...")
        
        # Disable capture button while dataset is being captured
        self.btn_capture_dataset.setEnabled(False)
        self.btn_capture_dataset.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/big_clock.png)")
        
        self.btn_close.setEnabled(False)
        
        # End camera streaming thread
        self.running = False
        self.camera_thread.join()
        time.sleep(.25)
        
        # Display overlay message on camera stream
        self.label_stream.hide()
        self.capturing_overlay.show()
        
        # Update GUI
        QCoreApplication.processEvents()
        time.sleep(.5)
    
        # Start new thread for SFF capture
        # "Patient1" is a placeholder name, will need to add some sort of iterative naming function
        
        # I'm using the base threading module to handle threads rather than QThreads,
        # since the GUI needs to be locked while a dataset is being captured
        self.capture_thread = threading.Thread(target=self.cerv.captureCont(dataset_name="Patient1",
                                                                            highresol=True))
        self.capture_thread.daemon = True
        self.capture_thread.start()
        
        self.btn_close.setEnabled(True)
        
        # Wait for SFF capture thread to complete
        self.capturing_overlay.hide()
        self.label_stream.show()
        QCoreApplication.processEvents()
        
        # Restart camera stream thread
        print("Restarting camera stream...")
        self.running = True
        self.camera_thread = threading.Thread(target=self.update_camera_viewer)
        self.camera_thread.daemon = True
        self.camera_thread.start()
        
        # Re-enable capture button while dataset is being captured
        self.btn_capture_dataset.setEnabled(True)
        self.btn_capture_dataset.setStyleSheet("border-image: url(/home/pi/Desktop/CervImage_GUI/gui_app/icons/big_camera_icon.png)")
        QCoreApplication.processEvents()
        # might need to be a shorter time
        time.sleep(.25)
                
        
    def close_window(self):
        # End camera stream thread
        self.running = False
        time.sleep(.5)
        self.camera_thread.join()
        print("Camera stream thread ended...")
        # Shutdown CervImage 
        self.cerv.shutdownDevice()
        # Close window
        self.close()
         
