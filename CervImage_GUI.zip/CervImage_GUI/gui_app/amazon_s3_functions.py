# Amazon S3 test script
from PyQt5.QtCore import Qt, QCoreApplication, QObject, QThread, pyqtSignal
from boto3.session import Session
#from botocore.client import ClientError
#import boto3
import os
#import copy
import time
from pathlib import Path
# Imports config file settings to determine which buckets to use
import pickle
"""
curdir = os.getcwd() + "//"
curdir = curdir.replace("\\","//").replace("//","/")
configName = "amazon_config.txt"
fullpath = curdir + configName

with open(fullpath, 'rb') as handle: # Reads in raw file
	configRaw = handle.read()
config = pickle.loads(configRaw) # Converts to Python dict

global trueBucket, queueBucket
trueBucket = config['bucket']
queueBucket = config['queuebucket']

print("\nCurrent bucket: ",trueBucket)
print("Queue bucket: ", queueBucket, "\n")
"""
class AmazonS3Server:
    
    def loadConfiguration(self):
        ### Modified: 10-12-21 ###
        ### Loads in Amazon configuration file
        ## Config file contains:
            # Bucket name
            # Queue bucket name
        
        configName = "amazon_config.txt"
        
        self.workDir = os.path.realpath(__file__)
        self.workDir = self.workDir.replace("\\","//").replace("//","/")
        self.workDir = str.split(self.workDir, "/")
        self.workDir = self.workDir[:-1]
        self.workingDir = "/".join(self.workDir) + "/"
        print("Code directory: ", self.workingDir)
        
        configPath = self.workingDir + configName
        print("Config path: ", configPath)
        
        with open(configPath, 'rb') as handle: # Reads in raw file
        	configRaw = handle.read()
        config = pickle.loads(configRaw) # Converts to Python dict
        
        self.trueName = config['bucket']
        self.queueName = config['queuebucket']
        #lobal trueBucket, queueBucket
        #trueBucket = config['bucket']
        #queueBucket = config['queuebucket']
        
        print("\nCurrent bucket: ",self.trueName)
        print("Queue bucket: ", self.queueName, "\n")
    
    def testConnection(self):
        try:
            test = self.s3.meta.client.head_bucket(Bucket=self.trueName)#'cervixstudy1')
            #print(test)
            print("Connected to S3")
            self.success = True
        except:# ClientError:
            print("Failed to connect to S3")
            self.success = False
        
        #return self.success
    
    def __init__(self):#, prefix):
        #global trueBucket, queueBucket
        #global ACCESS_KEY, SECRET_KEY 

        self.ACCESS_KEY = 'AKIAI3OR53XEUVTFKADA'
        self.SECRET_KEY = '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'
        
        print("Starting session")
        
        self.session = Session(aws_access_key_id=self.ACCESS_KEY,
                      aws_secret_access_key=self.SECRET_KEY)
        
        self.s3 = self.session.resource('s3')
        
        self.loadConfiguration() # Gets bucket names and sets up directories
        
        maindir = Path(self.workingDir)#os.getcwd())#"/here/your/path/file.txt")
        maindir = maindir.parent.absolute()
        maindir = os.path.dirname(maindir) + "/"
        maindir = maindir.replace("\\","/").replace("//","/")
        #maindir = "C:/Users/Stanley/Desktop/" #"/home/pi/Desktop/"
        self.imageDir = maindir+"Image_Library/"
        #self.imageDir = self.workingDir + "Image_Library/" # Folder where datasets are stored
        
        self.trueBucket = self.s3.Bucket(self.trueName)#'cervixstudy1')
        print("imageDir: ", self.imageDir)
        
        
        self.testConnection()
        
        ### PENDING 3D MODEL BUCKET
        if self.success:#self.testConnection():
            #global s3queue, queue_bucket
            self.s3queue = self.session.resource('s3')
            self.queueBucket = self.s3queue.Bucket(self.queueName)#'cervixstudy1queue')
        ###
        
        
       # return
        #self.prefix = '/home/pi/Desktop/Image_Library/'
    
    def parseFilepath(self, path):
        if path[-1] == "\\":
            if "/" in path:
                path = path.replace("/","\\")
                 
        if path[-1] != "/":
            path =  path + "/"

         #datasetname = dataset_name
        path = path.replace("\\","/").replace("//","/")
        print("Dataset name before parsing: ",path)
        
        print("self.imageDir is: ", self.imageDir)
        if self.imageDir in path:
               print("Prefix in filename")
               #filenames = os.listdir(datasetname)
        else:
               print("Adding prefix to filename")
              # datasetname = pref + datasetname
               path = self.imageDir + path
               #filenames = os.listdir(datasetname)
               print("Dataset name after parsing: ", path)
               
        datasetName = str.split(path, "/")
        datasetName = datasetName[-3] + "/" + datasetName[-2]
        
        print("Returned datasetName as: ", datasetName)
        return [path, datasetName]
 
    def uploadDataset(self, dataset_name):
        
        if self.success:
            datasetname, rawName = self.parseFilepath(dataset_name)
            filenames = os.listdir(datasetname)
            #filenames = os.listdir(prefix+datasetname)
            print(filenames)
            print("Found "+str(len(filenames)) + " files in directory")
            print("Starting upload")
            
            
            ### Saves text file to indicate that the upload was successful
            TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
            f = open(datasetname+'upload.txt','w')#opening a txt file to write info to
            #Writing to the file
            f.write("Files uploaded on\n")
            f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
            #############################################################
            hasLesion = False
            
            self.count = len(filenames)#33#len(filenames)
            for i in range(len(filenames)):
                if (filenames[i] == 'data.txt') or ('Image' in filenames[i]):# or ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    localname = datasetname+filenames[i]
                    localname = localname.replace("\\","/")
                    servername= "Image_Library/"+rawName+"/"+filenames[i]#datasetname[len(pref):]+filenames[i]
                    servername= servername.replace("\\","/")
                    print(servername)
                    self.queueBucket.upload_file(localname, servername)
                    self.count -= 1
                elif ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    hasLesion = True
                    continue
              
            ### UPLOADS LESION IF NOT ALREADY DONE    
            if hasLesion:
               # lesionfilename = datasetname.replace("\\","/")#self.uploadLesion(datasetname.replace("\\","/"))
               #if lesionfilename[-1] != "/":
                #    lesionfilename += "/"
                #lesionfilename = datasetname
                check = os.path.exists(datasetname+"lesionupload.txt")
             
                if check == False: # if there is no upload file
                    self.uploadLesion(datasetname)
                    self.count -= 1
                   # self.selectbutton['state'] = 'normal'
                   # self.selectbutton.configure(text = "Upload\nDataset")
                   # self.root.update_idletasks()
                else: # checks if the upload was incomplete
                    file = open(datasetname+"lesionupload.txt", 'r')
                    for line in file:
                        if line == "SUCCESS":
                            print("Lesion already uploaded")
                            file.close()
                    
                    file.close()        
            ###         
               
                
            print("Complete!")
            f = open(datasetname+'upload.txt','a')#opening a txt file to write info to
            #Writing to the file
            f.write("SUCCESS")
            #f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
        else:
            print("Not connected to S3!")
        
    def uploadLesion(self, dataset_name):
        """
        ACCESS_KEY = 'AKIAI3OR53XEUVTFKADA'
        SECRET_KEY = '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'
        
        print("Starting session")
        session = Session(aws_access_key_id=ACCESS_KEY,
                      aws_secret_access_key=SECRET_KEY)
        s3 = session.resource('s3')
        self.trueBucket = s3.Bucket('cervimagetest1')
        print("Connected to S3")
        
        #prefix = '/home/pi/Desktop/Image_Library/'
        #dataset_name = 'VERDI2'
        
        """
        if self.success:
            datasetname, rawName = self.parseFilepath(dataset_name)
            print("Starting upload")
            
            ### Saves text file to indicate that the upload was successful
            TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
            f = open(datasetname+'lesionupload.txt','w')#opening a txt file to write info to
            #Writing to the file
            f.write("Lesion files uploaded on\n")
            f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
            #############################################################
            
            
            #for i in range(len(filenames)):
            filenames = ["lesion_info.txt","lesionmask.png"]
            self.count = len(filenames)
            for file in filenames:
                localname = datasetname+file
                    
                servername= "Image_Library/"+rawName+"/"+file#filename[len(pref):]+file
                print("local name", localname)
                print("server name", servername)
                #servername= servername.replace("\\","/")
                #servername= servername.replace("//","/")
                #print(servername)
                self.queueBucket.upload_file(localname, servername)
                self.count -= 1
            print("Complete!")

            f = open(datasetname+'lesionupload.txt','a')#opening a txt file to write info to
            #Writing to the file
            f.write("SUCCESS")
            #f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
        else:
            print("Not connected to S3!")

    def downloadDataset(self, dataset_name, lesiononly = False, modelonly = False):
        if self.success:
            #dataset_name = dataset_name + "\\"
            #cleanpref = self.prefix.replace("\\","/").replace("//","/")
            #cleanname = dataset_name.replace("\\","/").replace("//","/")
            datasetname, rawName = self.parseFilepath(dataset_name)
            #print(cleanpref+cleanname)
            fnames = self.checkserver("Image_Library/"+rawName+"/")#cleanpref+dataset_name)
            print(fnames)
            
            if fnames != False:
                
                try:
                    os.chdir(datasetname)#cleanpref+cleanname)#self.prefix+dataset_name)#'Image_Library/'+dirname)
                except OSError:
                    print("New directory", datasetname, "created")
                    os.makedirs(datasetname)#cleanpref+cleanname)
                    os.chdir(datasetname)#cleanpref+cleanname)
        
                print("Starting download")
                
                # Filenames to get
                ltxt = 'lesion_info.txt'
                lmask = 'lesionmask.png'
                dmap = 'depthmap.dat'
                afoc = 'allfocus.png'
                vol = 'volume.dat'
                
                lib = 'Image_Library/'
                serverFolder = lib+rawName+"/"
                if lesiononly:
                    self.trueBucket.download_file(datasetname+ltxt, serverFolder+ltxt)
                    self.trueBucket.download_file(datasetname+lmask, serverFolder+lmask)
                elif modelonly:

                    self.trueBucket.download_file(datasetname+dmap, serverFolder+dmap)
                    self.trueBucket.download_file(datasetname+afoc, serverFolder+afoc)
                    self.trueBucket.download_file(datasetname+vol, serverFolder+vol)
                else:  
                    for i in range(len(fnames)):
                        servername = serverFolder+fnames[i]
                        self.trueBucket.download_file(servername,fnames[i])
                print("Complete!")
                os.chdir(self.workingDir)#'C:/Users/Stanley/Desktop/Windows CervImage GUI Updating/')
            else:
                print("No datasets for this patient")
        else:
            print("Not connected to S3!")
    
    def checkserver(self, dataset_name, number=False, model3D=False):
        if self.success:
            
            datasetname, rawName = self.parseFilepath(dataset_name)
            
            
            #cleanpref = self.prefix.replace("//","/").replace("\\","/")
           # cleanname = dataset_name.replace("//","/").replace("\\","/")
            
            #curname = cleanname[len(cleanpref):-1]
          #  print(curname)
            
           # pref = 'Image_Library/'
            #print(pref+curname)
            
            #print(curname)
            
            #if model3D:
            #   checkbucket = queue_bucket
            #else:
            #checkbucket = self.trueBucket
            
            objs = []
            containsmodel = False
            
            lib = "Image_Library/"
            serverFolder = lib+rawName
            for obj in self.trueBucket.objects.filter(Prefix=serverFolder):#pref+curname):
               # print(obj.key[len(pref+curname+'/'):])
               
                cur = obj.key[len(serverFolder):]
                if '.dat' in cur:
                    containsmodel = True
                    
                if cur != "":
                    objs.append(cur)
                
               # response = self.trueBucket.list_objects(prefix+curname)
            
            if number:
                return len(objs)
            if model3D:
                return containsmodel
            else:
                if len(objs) > 0:
                    return objs
                else:
                    return False
                
        else:      
            print("Not connected to S3!")
            return None

#res = AmazonS3Server("C:\\Users\\Stanley\\Desktop\\Image_Library\\")
#res.checkserver("C:\\Users\\Stanley\\Desktop\\Image_Library\\"+"LOL\\dataset_8\\",number=True)#uploadDataset("LOL\\dataset_8")
#res.downloadDataset("patientdataset\\dataset_1\\")
#print(res)
#uploadDataset("buddha2")
#downloadDataset("buddha2")
        

# Threaded upload for single dataset
class UploadThread(QObject, AmazonS3Server):
    finished = pyqtSignal()
    progress = pyqtSignal(int)
    def __init__(self, current_sub_dataset, current_dataset, parent=None):
        super(UploadThread, self).__init__(parent)
        
        self.current_sub_dataset = current_sub_dataset
        self.current_dataset = current_dataset

    def run(self):
        
        if self.success:
            datasetname, rawName = self.parseFilepath(self.current_dataset+ '/'+ self.current_sub_dataset)
            filenames = os.listdir(datasetname)
            print(filenames)
            print("Found "+str(len(filenames)) + " files in directory")
            print("Starting upload")
            
            ### Saves text file to indicate that the upload was successful
            TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
            f = open(datasetname+'upload.txt','w')#opening a txt file to write info to
            #Writing to the file
            f.write("Files uploaded on\n")
            f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
            #hasLesion = False
            self.count = len(filenames)
            for i in range(len(filenames)):
                if (filenames[i] == 'data.txt') or ('Image' in filenames[i]):# or ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    localname = datasetname+filenames[i]
                    localname = localname.replace("\\","/")
                    servername= "Image_Library/"+rawName+"/"+filenames[i]#datasetname[len(pref):]+filenames[i]
                    servername= servername.replace("\\","/")
                    print(servername)
                    self.queueBucket.upload_file(localname, servername)
                    self.count -= 1
                    self.progress.emit(self.count)
            
                elif ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    hasLesion = True
                    continue
            self.progress.emit(0)
            print("Complete!")
            
            f = open(datasetname+'upload.txt','a')#opening a txt file to write info to
            #Writing to the file
            f.write("SUCCESS")
            #f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
            self.finished.emit()
        else:
            print("Not connected to S3!")
        
# need to improve naming of datasets
# Threaded upload for all datasets of a given patient
class UploadPatientThread(QObject, AmazonS3Server):
    finished = pyqtSignal()
    progress = pyqtSignal(int)
    def __init__(self, sub_datasets, current_dataset, parent=None):
        super(UploadPatientThread, self).__init__(parent)
        
        self.sub_datasets = sub_datasets
        self.current_dataset = current_dataset
        
    
    def upload_dataset(self, sub_dataset):
        
        if self.success:
            datasetname, rawName = self.parseFilepath(self.current_dataset+ '/'+ sub_dataset)
            filenames = os.listdir(datasetname)
            print(filenames)
            print("Found "+str(len(filenames)) + " files in directory")
            print("Starting upload")
            
            ### Saves text file to indicate that the upload was successful
            TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
            f = open(datasetname+'upload.txt','w')#opening a txt file to write info to
            #Writing to the file
            f.write("Files uploaded on\n")
            f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
            #hasLesion = False
            #self.count = len(filenames)
            for i in range(len(filenames)):
                if (filenames[i] == 'data.txt') or ('Image' in filenames[i]):# or ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    localname = datasetname+filenames[i]
                    localname = localname.replace("\\","/")
                    servername= "Image_Library/"+rawName+"/"+filenames[i]#datasetname[len(pref):]+filenames[i]
                    servername= servername.replace("\\","/")
                    print(servername)
                    self.queueBucket.upload_file(localname, servername)
                    self.file_count -= 1
                    self.progress.emit(self.file_count)
            
                elif ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    hasLesion = True
                    continue
            
            print("Complete!")
            
            f = open(datasetname+'upload.txt','a')#opening a txt file to write info to
            #Writing to the file
            f.write("SUCCESS")
            #f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
           # self.finished.emit()
        else:
            print("Not connected to S3!")
    
    def run(self):
        print('Uploading all datasets for ' + str(self.current_dataset))
        print()
        self.file_count = 0
        for sub_dataset in self.sub_datasets:
            datasetname, rawName = self.parseFilepath(self.current_dataset+ '/'+ sub_dataset)
            filenames = os.listdir(datasetname)
            self.file_count += len(filenames)
            
        for sub_dataset in self.sub_datasets:
            self.upload_dataset(sub_dataset)
        self.progress.emit(0)
        self.finished.emit()

# Threaded upload for all datasets
class UploadAllThread(QObject, AmazonS3Server):
    finished = pyqtSignal()
    progress = pyqtSignal(int)
    
    def __init__(self, all_datasets,path, parent=None):
        super(UploadAllThread, self).__init__(parent)
        self.all_datasets = all_datasets
        self.path = path
        
    def load_sub_datasets(self):
        if self.current_dataset:
            self.sub_datasets = [folder for folder in os.listdir(os.path.join(self.path, self.current_dataset))
                            if os.path.isdir(os.path.join(self.path, self.current_dataset, folder))]
    def upload_dataset(self, sub_dataset):
        
        if self.success:
            datasetname, rawName = self.parseFilepath(self.current_dataset+ '/'+ sub_dataset)
            filenames = os.listdir(datasetname)
            print(filenames)
            print("Found "+str(len(filenames)) + " files in directory")
            print("Starting upload")
            
            ### Saves text file to indicate that the upload was successful
            TIME = time.strftime("%d-%b-%Y_%H%M_%S",time.localtime())
            f = open(datasetname+'upload.txt','w')#opening a txt file to write info to
            #Writing to the file
            f.write("Files uploaded on\n")
            f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
            #hasLesion = False
            for i in range(len(filenames)):
                if (filenames[i] == 'data.txt') or ('Image' in filenames[i]):# or ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    localname = datasetname+filenames[i]
                    localname = localname.replace("\\","/")
                    servername= "Image_Library/"+rawName+"/"+filenames[i]#datasetname[len(pref):]+filenames[i]
                    servername= servername.replace("\\","/")
                    print(servername)
                    self.queueBucket.upload_file(localname, servername)
                    self.file_count -= 1
                    self.progress.emit(self.file_count)
            
                elif ('lesion_info.txt' == filenames[i]) or (filenames[i] == 'lesionmask.png'):
                    hasLesion = True
                    continue
            
            print("Complete!")
            
            f = open(datasetname+'upload.txt','a')#opening a txt file to write info to
            #Writing to the file
            f.write("SUCCESS")
            #f.write("Date = " + TIME + ' \n')
            f.close() #must also close the file
        else:
            print("Not connected to S3!")
    
    def run(self):
        print('Uploading data for all patients')
        print(self.all_datasets)
        self.file_count = 0
        
        for dataset in self.all_datasets:
            self.current_dataset = dataset
            self.load_sub_datasets()
            for sub_dataset in self.sub_datasets:
                datasetname, rawName = self.parseFilepath(self.current_dataset+ '/'+ sub_dataset)
                filenames = os.listdir(datasetname)
                self.file_count += len(filenames)
        print('Total files: ' + str(self.file_count))    
        print()
        for dataset in self.all_datasets:
            self.current_dataset = dataset
            self.load_sub_datasets()
            for sub_dataset in self.sub_datasets:
                self.upload_dataset(sub_dataset)
        self.progress.emit(0)
        self.finished.emit()
if __name__ == "__main__":
    testAmazon = AmazonS3Server()