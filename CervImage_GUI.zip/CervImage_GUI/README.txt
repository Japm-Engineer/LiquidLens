Starting GUI:

(1) Open terminal

(2) Enter "cd Desktop/CervImage_GUI" to navigate to GUI folder

(3) Enter "sudo python3 main.py" to start the GUI application